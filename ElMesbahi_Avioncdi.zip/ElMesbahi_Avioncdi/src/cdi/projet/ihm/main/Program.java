package cdi.projet.ihm.main;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import cdi.projet.ihm.component.FenetreJeu;

public class Program {
	public static void main(String[] args) throws ParseException, Throwable {
		new FenetreJeu();
		
	      
	}
}
