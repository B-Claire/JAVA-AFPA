package cdi.projet.ihm.data.meteorite;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.util.Random;

import javax.swing.JPanel;

import cdi.projet.ihm.data.avion.Avion;

public abstract class MeteoriteAbstract implements Meteorite {
	protected static int CMPT = 0;
	protected static final int WHITE_STEP = 0;
	private static final int ACCELERATEUR = 10;
	
	protected int posY;
	protected int posX = Integer.MIN_VALUE;
	protected boolean detruit;
	protected boolean remplacable;
	protected Meteorite precedent;
	protected int id;
	protected Avion plane;
	protected int width;
	protected int height;
	protected int nbEmptyStep;
	protected Image img;
	protected JPanel pan;
	protected int degat;
	protected int indexImage = 0;
	
	public MeteoriteAbstract(JPanel p, Meteorite m, Avion pl) {
		this.id = MeteoriteAbstract.CMPT++;
		this.img = getImageImpaire();
		this.pan = p;
		this.width = getWidth();
		this.height = getHeight();
		this.degat = getDegat();
		this.precedent = m;
		this.plane = pl;
	}
	
	@Override
	public void dessiner(Graphics g, boolean pause) {
		if(pause) {
			Graphics2D g2d = (Graphics2D) g.create();
			g2d.drawImage(img, this.posX, this.posY, this.width, this.height, pan);
			return;
		}
		if ((this.posX == Integer.MIN_VALUE && this.id == 0)
				|| (this.posX == Integer.MIN_VALUE)
				&& (this.precedent.getPosY() > this.pan.getHeight() / 4)) {
			if(this.detruit) {
				this.remplacable = true;
			}else {
				this.posX = new Random().nextInt(this.pan.getWidth() - this.width);
				this.posY = 0;
			}
		} else if ( this.posY >= this.pan.getHeight() ) {
			this.remplacable = true;
		}
		if (this.posX != Integer.MIN_VALUE) {
			if (nbEmptyStep < WHITE_STEP) {
				this.nbEmptyStep++;
			} else {
				if(this.detruit) {
					this.posY += getMoveStepAfterDestruction()+ACCELERATEUR;
				} else {
					this.posY += getMoveStep()+ACCELERATEUR;
				}

				this.nbEmptyStep = 0;
			}
		}

		if(! this.detruit) {
			this.indexImage %= 2;
			if (indexImage == 0) {
				this.img = getImagePaire();
			} else {
				this.img = getImageImpaire();
			}
			this.indexImage++;
		}

		Graphics2D g2d = (Graphics2D) g.create();
		g2d.drawImage(img, this.posX, this.posY, this.width, this.height, pan);

		this.verifierImpacte();
	}
	
	public void verifierImpacte() {
		if (!this.detruit && (((this.posX + this.width > this.plane.getPosX()
				&& this.posX + this.width < this.plane.getPosX() + this.plane.getWidth())
				|| (this.posX > this.plane.getPosX() && this.posX < this.plane.getPosX() + this.plane.getWidth()))
				&& (this.posY + this.height > this.plane.getPosY()
						&& this.posY + this.height < this.plane.getPosY() + this.plane.getHeight()))
				) {
			this.plane.impacte(this.degat);
			this.img = getImageImpacte();
			this.degat=0;
			this.detruit = true;
		}
	}
	
	@Override
	public int getPosY() {
		return this.posY;
	}
	
	@Override
	public boolean isDetruit() {
		return detruit;
	}

	@Override
	public boolean isRemplacable() {
		return remplacable;
	}

	public static void init() {
		CMPT = 0;
	}
	
	
	@Override
	public Meteorite getPrecedent() {
		return precedent;
	}

	@Override
	public void setPrecedent(Meteorite precedent) {
		this.precedent = precedent;
	}

	
}
